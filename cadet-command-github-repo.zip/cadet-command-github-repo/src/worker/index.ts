import { Hono } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import {
  authMiddleware,
  deleteSession,
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import {
  CadetSchema,
  PlatoonSchema,
  CompanySchema,
  InstructorSchema,
  EventSchema,
  PracticeSchema,
  DisciplinaryActionSchema,
} from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

// Auth routes
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60,
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Cadets routes
app.get("/api/cadets", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM cadets WHERE user_id = ? ORDER BY last_name, first_name"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.post("/api/cadets", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = CadetSchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO cadets (user_id, first_name, last_name, rank, platoon_id, company_id, email, phone, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(
      user.id,
      data.first_name,
      data.last_name,
      data.rank,
      data.platoon_id || null,
      data.company_id || null,
      data.email || null,
      data.phone || null
    )
    .run();

  return c.json({ id: result.meta.last_row_id }, 201);
});

app.put("/api/cadets/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = CadetSchema.parse(body);

  await c.env.DB.prepare(
    `UPDATE cadets SET first_name = ?, last_name = ?, rank = ?, platoon_id = ?, company_id = ?, email = ?, phone = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND user_id = ?`
  )
    .bind(
      data.first_name,
      data.last_name,
      data.rank,
      data.platoon_id || null,
      data.company_id || null,
      data.email || null,
      data.phone || null,
      id,
      user.id
    )
    .run();

  return c.json({ success: true });
});

app.delete("/api/cadets/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  await c.env.DB.prepare("DELETE FROM cadets WHERE id = ? AND user_id = ?")
    .bind(id, user.id)
    .run();

  return c.json({ success: true });
});

// Platoons routes
app.get("/api/platoons", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM platoons WHERE user_id = ? ORDER BY name"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.post("/api/platoons", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = PlatoonSchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO platoons (user_id, name, commander_id, company_id, updated_at)
     VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(
      user.id,
      data.name,
      data.commander_id || null,
      data.company_id || null
    )
    .run();

  return c.json({ id: result.meta.last_row_id }, 201);
});

app.put("/api/platoons/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = PlatoonSchema.parse(body);

  await c.env.DB.prepare(
    `UPDATE platoons SET name = ?, commander_id = ?, company_id = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND user_id = ?`
  )
    .bind(data.name, data.commander_id || null, data.company_id || null, id, user.id)
    .run();

  return c.json({ success: true });
});

app.delete("/api/platoons/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  await c.env.DB.prepare("DELETE FROM platoons WHERE id = ? AND user_id = ?")
    .bind(id, user.id)
    .run();

  return c.json({ success: true });
});

// Companies routes
app.get("/api/companies", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM companies WHERE user_id = ? ORDER BY name"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.post("/api/companies", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = CompanySchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO companies (user_id, name, commander_id, updated_at)
     VALUES (?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(user.id, data.name, data.commander_id || null)
    .run();

  return c.json({ id: result.meta.last_row_id }, 201);
});

app.put("/api/companies/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = CompanySchema.parse(body);

  await c.env.DB.prepare(
    `UPDATE companies SET name = ?, commander_id = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND user_id = ?`
  )
    .bind(data.name, data.commander_id || null, id, user.id)
    .run();

  return c.json({ success: true });
});

app.delete("/api/companies/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  await c.env.DB.prepare("DELETE FROM companies WHERE id = ? AND user_id = ?")
    .bind(id, user.id)
    .run();

  return c.json({ success: true });
});

// Instructors routes
app.get("/api/instructors", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM instructors WHERE user_id = ? ORDER BY last_name, first_name"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.post("/api/instructors", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = InstructorSchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO instructors (user_id, first_name, last_name, rank, branch, email, phone, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(
      user.id,
      data.first_name,
      data.last_name,
      data.rank,
      data.branch,
      data.email || null,
      data.phone || null
    )
    .run();

  return c.json({ id: result.meta.last_row_id }, 201);
});

app.put("/api/instructors/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = InstructorSchema.parse(body);

  await c.env.DB.prepare(
    `UPDATE instructors SET first_name = ?, last_name = ?, rank = ?, branch = ?, email = ?, phone = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND user_id = ?`
  )
    .bind(
      data.first_name,
      data.last_name,
      data.rank,
      data.branch,
      data.email || null,
      data.phone || null,
      id,
      user.id
    )
    .run();

  return c.json({ success: true });
});

app.delete("/api/instructors/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  await c.env.DB.prepare("DELETE FROM instructors WHERE id = ? AND user_id = ?")
    .bind(id, user.id)
    .run();

  return c.json({ success: true });
});

// Events routes
app.get("/api/events", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM events WHERE user_id = ? ORDER BY event_date DESC"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.post("/api/events", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = EventSchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO events (user_id, name, description, event_date, location, updated_at)
     VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(
      user.id,
      data.name,
      data.description || null,
      data.event_date,
      data.location || null
    )
    .run();

  return c.json({ id: result.meta.last_row_id }, 201);
});

app.put("/api/events/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = EventSchema.parse(body);

  await c.env.DB.prepare(
    `UPDATE events SET name = ?, description = ?, event_date = ?, location = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND user_id = ?`
  )
    .bind(
      data.name,
      data.description || null,
      data.event_date,
      data.location || null,
      id,
      user.id
    )
    .run();

  return c.json({ success: true });
});

app.delete("/api/events/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  await c.env.DB.prepare("DELETE FROM events WHERE id = ? AND user_id = ?")
    .bind(id, user.id)
    .run();

  return c.json({ success: true });
});

// Practices routes
app.get("/api/practices", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM practices WHERE user_id = ? ORDER BY practice_date DESC"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.post("/api/practices", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = PracticeSchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO practices (user_id, name, description, practice_date, location, updated_at)
     VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(
      user.id,
      data.name,
      data.description || null,
      data.practice_date,
      data.location || null
    )
    .run();

  return c.json({ id: result.meta.last_row_id }, 201);
});

app.put("/api/practices/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = PracticeSchema.parse(body);

  await c.env.DB.prepare(
    `UPDATE practices SET name = ?, description = ?, practice_date = ?, location = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND user_id = ?`
  )
    .bind(
      data.name,
      data.description || null,
      data.practice_date,
      data.location || null,
      id,
      user.id
    )
    .run();

  return c.json({ success: true });
});

app.delete("/api/practices/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  await c.env.DB.prepare("DELETE FROM practices WHERE id = ? AND user_id = ?")
    .bind(id, user.id)
    .run();

  return c.json({ success: true });
});

// Disciplinary actions routes
app.get("/api/disciplinary-actions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM disciplinary_actions WHERE user_id = ? ORDER BY incident_date DESC"
  )
    .bind(user.id)
    .all();

  return c.json(results);
});

app.get("/api/disciplinary-actions/cadet/:cadetId", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const cadetId = c.req.param("cadetId");
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM disciplinary_actions WHERE user_id = ? AND cadet_id = ? ORDER BY incident_date DESC"
  )
    .bind(user.id, cadetId)
    .all();

  return c.json(results);
});

app.post("/api/disciplinary-actions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = DisciplinaryActionSchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO disciplinary_actions (user_id, cadet_id, infraction, severity, corrective_action, incident_date, resolution_date, notes, is_resolved, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`
  )
    .bind(
      user.id,
      data.cadet_id,
      data.infraction,
      data.severity,
      data.corrective_action,
      data.incident_date,
      data.resolution_date || null,
      data.notes || null,
      data.is_resolved || 0
    )
    .run();

  return c.json({ id: result.meta.last_row_id }, 201);
});

app.put("/api/disciplinary-actions/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = DisciplinaryActionSchema.parse(body);

  await c.env.DB.prepare(
    `UPDATE disciplinary_actions SET cadet_id = ?, infraction = ?, severity = ?, corrective_action = ?, incident_date = ?, resolution_date = ?, notes = ?, is_resolved = ?, updated_at = CURRENT_TIMESTAMP
     WHERE id = ? AND user_id = ?`
  )
    .bind(
      data.cadet_id,
      data.infraction,
      data.severity,
      data.corrective_action,
      data.incident_date,
      data.resolution_date || null,
      data.notes || null,
      data.is_resolved || 0,
      id,
      user.id
    )
    .run();

  return c.json({ success: true });
});

app.delete("/api/disciplinary-actions/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  await c.env.DB.prepare(
    "DELETE FROM disciplinary_actions WHERE id = ? AND user_id = ?"
  )
    .bind(id, user.id)
    .run();

  return c.json({ success: true });
});

export default app;
