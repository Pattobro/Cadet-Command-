import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import Modal from "@/react-app/components/Modal";
import Button from "@/react-app/components/Button";
import Input from "@/react-app/components/Input";
import Select from "@/react-app/components/Select";
import { Plus, Edit2, Trash2, GraduationCap } from "lucide-react";
import { InstructorType, INSTRUCTOR_RANKS, BRANCHES } from "@/shared/types";

export default function Instructors() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [instructors, setInstructors] = useState<InstructorType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInstructor, setEditingInstructor] = useState<InstructorType | null>(null);
  const [formData, setFormData] = useState<{
    first_name: string;
    last_name: string;
    rank: typeof INSTRUCTOR_RANKS[number];
    branch: typeof BRANCHES[number];
    email: string;
    phone: string;
  }>({
    first_name: "",
    last_name: "",
    rank: INSTRUCTOR_RANKS[0],
    branch: BRANCHES[0],
    email: "",
    phone: "",
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchInstructors();
    }
  }, [user]);

  const fetchInstructors = async () => {
    const response = await fetch("/api/instructors");
    const data = await response.json();
    setInstructors(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      email: formData.email || null,
      phone: formData.phone || null,
    };

    if (editingInstructor) {
      await fetch(`/api/instructors/${editingInstructor.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/instructors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    fetchInstructors();
    closeModal();
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this instructor?")) {
      await fetch(`/api/instructors/${id}`, { method: "DELETE" });
      fetchInstructors();
    }
  };

  const openModal = (instructor?: InstructorType) => {
    if (instructor) {
      setEditingInstructor(instructor);
      setFormData({
        first_name: instructor.first_name,
        last_name: instructor.last_name,
        rank: instructor.rank,
        branch: instructor.branch,
        email: instructor.email || "",
        phone: instructor.phone || "",
      });
    } else {
      setEditingInstructor(null);
      setFormData({
        first_name: "",
        last_name: "",
        rank: INSTRUCTOR_RANKS[0],
        branch: BRANCHES[0],
        email: "",
        phone: "",
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingInstructor(null);
  };

  if (isPending || !user) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Instructors</h1>
            <p className="text-slate-400">Manage JROTC instructors and cadre</p>
          </div>
          <Button onClick={() => openModal()}>
            <Plus className="w-5 h-5 mr-2 inline" />
            Add Instructor
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {instructors.map((instructor) => (
            <div
              key={instructor.id}
              className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
                    <GraduationCap className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      {instructor.first_name} {instructor.last_name}
                    </h3>
                    <p className="text-sm text-[#d4af37]">{instructor.rank}</p>
                    <p className="text-xs text-slate-400">{instructor.branch}</p>
                  </div>
                </div>
              </div>

              {(instructor.email || instructor.phone) && (
                <div className="space-y-1 mb-4 text-sm">
                  {instructor.email && <p className="text-slate-400">{instructor.email}</p>}
                  {instructor.phone && <p className="text-slate-400">{instructor.phone}</p>}
                </div>
              )}

              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => openModal(instructor)}
                  className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(instructor.id!)}
                  className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {instructors.length === 0 && (
          <div className="text-center py-12">
            <GraduationCap className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">No instructors yet. Add your first instructor to get started.</p>
          </div>
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingInstructor ? "Edit Instructor" : "Add Instructor"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="First Name"
              value={formData.first_name}
              onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
              required
            />
            <Input
              label="Last Name"
              value={formData.last_name}
              onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
              required
            />
          </div>

          <Select
            label="Rank"
            value={formData.rank}
            onChange={(e) => setFormData({ ...formData, rank: e.target.value as any })}
            options={INSTRUCTOR_RANKS.map((rank) => ({ value: rank, label: rank }))}
            required
          />

          <Select
            label="Armed Forces Branch"
            value={formData.branch}
            onChange={(e) => setFormData({ ...formData, branch: e.target.value as any })}
            options={BRANCHES.map((branch) => ({ value: branch, label: branch }))}
            required
          />

          <Input
            label="Email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />

          <Input
            label="Phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          />

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button type="submit">
              {editingInstructor ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
