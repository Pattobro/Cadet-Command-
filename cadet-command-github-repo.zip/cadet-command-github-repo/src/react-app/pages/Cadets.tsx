import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import Modal from "@/react-app/components/Modal";
import Button from "@/react-app/components/Button";
import Input from "@/react-app/components/Input";
import Select from "@/react-app/components/Select";
import { Plus, Edit2, Trash2, Shield } from "lucide-react";
import { CadetType, PlatoonType, CompanyType, CADET_RANKS } from "@/shared/types";

export default function Cadets() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [cadets, setCadets] = useState<CadetType[]>([]);
  const [platoons, setPlatoons] = useState<PlatoonType[]>([]);
  const [companies, setCompanies] = useState<CompanyType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCadet, setEditingCadet] = useState<CadetType | null>(null);
  const [formData, setFormData] = useState<{
    first_name: string;
    last_name: string;
    rank: typeof CADET_RANKS[number];
    platoon_id: string;
    company_id: string;
    email: string;
    phone: string;
  }>({
    first_name: "",
    last_name: "",
    rank: CADET_RANKS[0],
    platoon_id: "",
    company_id: "",
    email: "",
    phone: "",
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchCadets();
      fetchPlatoons();
      fetchCompanies();
    }
  }, [user]);

  const fetchCadets = async () => {
    const response = await fetch("/api/cadets");
    const data = await response.json();
    setCadets(data);
  };

  const fetchPlatoons = async () => {
    const response = await fetch("/api/platoons");
    const data = await response.json();
    setPlatoons(data);
  };

  const fetchCompanies = async () => {
    const response = await fetch("/api/companies");
    const data = await response.json();
    setCompanies(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      platoon_id: formData.platoon_id ? Number(formData.platoon_id) : null,
      company_id: formData.company_id ? Number(formData.company_id) : null,
      email: formData.email || null,
      phone: formData.phone || null,
    };

    if (editingCadet) {
      await fetch(`/api/cadets/${editingCadet.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/cadets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    fetchCadets();
    closeModal();
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this cadet?")) {
      await fetch(`/api/cadets/${id}`, { method: "DELETE" });
      fetchCadets();
    }
  };

  const openModal = (cadet?: CadetType) => {
    if (cadet) {
      setEditingCadet(cadet);
      setFormData({
        first_name: cadet.first_name,
        last_name: cadet.last_name,
        rank: cadet.rank,
        platoon_id: cadet.platoon_id?.toString() || "",
        company_id: cadet.company_id?.toString() || "",
        email: cadet.email || "",
        phone: cadet.phone || "",
      });
    } else {
      setEditingCadet(null);
      setFormData({
        first_name: "",
        last_name: "",
        rank: CADET_RANKS[0],
        platoon_id: "",
        company_id: "",
        email: "",
        phone: "",
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingCadet(null);
  };

  if (isPending || !user) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Cadets</h1>
            <p className="text-slate-400">Manage cadet roster and assignments</p>
          </div>
          <Button onClick={() => openModal()}>
            <Plus className="w-5 h-5 mr-2 inline" />
            Add Cadet
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cadets.map((cadet) => (
            <div
              key={cadet.id}
              className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
                    <Shield className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      {cadet.first_name} {cadet.last_name}
                    </h3>
                    <p className="text-sm text-[#d4af37]">{cadet.rank}</p>
                  </div>
                </div>
              </div>

              {(cadet.email || cadet.phone) && (
                <div className="space-y-1 mb-4 text-sm">
                  {cadet.email && <p className="text-slate-400">{cadet.email}</p>}
                  {cadet.phone && <p className="text-slate-400">{cadet.phone}</p>}
                </div>
              )}

              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => openModal(cadet)}
                  className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(cadet.id!)}
                  className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {cadets.length === 0 && (
          <div className="text-center py-12">
            <Shield className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">No cadets yet. Add your first cadet to get started.</p>
          </div>
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingCadet ? "Edit Cadet" : "Add Cadet"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="First Name"
              value={formData.first_name}
              onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
              required
            />
            <Input
              label="Last Name"
              value={formData.last_name}
              onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
              required
            />
          </div>

          <Select
            label="Rank"
            value={formData.rank}
            onChange={(e) => setFormData({ ...formData, rank: e.target.value as any })}
            options={CADET_RANKS.map((rank) => ({ value: rank, label: rank }))}
            required
          />

          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Platoon"
              value={formData.platoon_id}
              onChange={(e) => setFormData({ ...formData, platoon_id: e.target.value })}
              options={[
                { value: "", label: "None" },
                ...platoons.map((p) => ({ value: p.id!, label: p.name })),
              ]}
            />
            <Select
              label="Company"
              value={formData.company_id}
              onChange={(e) => setFormData({ ...formData, company_id: e.target.value })}
              options={[
                { value: "", label: "None" },
                ...companies.map((c) => ({ value: c.id!, label: c.name })),
              ]}
            />
          </div>

          <Input
            label="Email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />

          <Input
            label="Phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          />

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button type="submit">
              {editingCadet ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
