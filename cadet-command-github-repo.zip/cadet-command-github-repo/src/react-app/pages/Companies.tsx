import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import Modal from "@/react-app/components/Modal";
import Button from "@/react-app/components/Button";
import Input from "@/react-app/components/Input";
import Select from "@/react-app/components/Select";
import { Plus, Edit2, Trash2, Building2 } from "lucide-react";
import { CompanyType, CadetType } from "@/shared/types";

export default function Companies() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [companies, setCompanies] = useState<CompanyType[]>([]);
  const [cadets, setCadets] = useState<CadetType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<CompanyType | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    commander_id: "",
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchCompanies();
      fetchCadets();
    }
  }, [user]);

  const fetchCompanies = async () => {
    const response = await fetch("/api/companies");
    const data = await response.json();
    setCompanies(data);
  };

  const fetchCadets = async () => {
    const response = await fetch("/api/cadets");
    const data = await response.json();
    setCadets(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      commander_id: formData.commander_id ? Number(formData.commander_id) : null,
    };

    if (editingCompany) {
      await fetch(`/api/companies/${editingCompany.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/companies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    fetchCompanies();
    closeModal();
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this company?")) {
      await fetch(`/api/companies/${id}`, { method: "DELETE" });
      fetchCompanies();
    }
  };

  const openModal = (company?: CompanyType) => {
    if (company) {
      setEditingCompany(company);
      setFormData({
        name: company.name,
        commander_id: company.commander_id?.toString() || "",
      });
    } else {
      setEditingCompany(null);
      setFormData({
        name: "",
        commander_id: "",
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingCompany(null);
  };

  const getCommanderName = (commanderId: number | null | undefined) => {
    if (!commanderId) return "Unassigned";
    const commander = cadets.find((c) => c.id === commanderId);
    return commander ? `${commander.first_name} ${commander.last_name}` : "Unknown";
  };

  if (isPending || !user) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Companies</h1>
            <p className="text-slate-400">Manage company organization and commanders</p>
          </div>
          <Button onClick={() => openModal()}>
            <Plus className="w-5 h-5 mr-2 inline" />
            Add Company
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {companies.map((company) => (
            <div
              key={company.id}
              className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
                    <Building2 className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{company.name}</h3>
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-xs text-slate-500 mb-1">Company Commander</p>
                <p className="text-sm text-[#d4af37] font-medium">{getCommanderName(company.commander_id)}</p>
              </div>

              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => openModal(company)}
                  className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(company.id!)}
                  className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {companies.length === 0 && (
          <div className="text-center py-12">
            <Building2 className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">No companies yet. Add your first company to get started.</p>
          </div>
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingCompany ? "Edit Company" : "Add Company"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Company Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., Alpha Company"
            required
          />

          <Select
            label="Company Commander"
            value={formData.commander_id}
            onChange={(e) => setFormData({ ...formData, commander_id: e.target.value })}
            options={[
              { value: "", label: "Select Commander" },
              ...cadets.map((c) => ({
                value: c.id!,
                label: `${c.first_name} ${c.last_name} - ${c.rank}`,
              })),
            ]}
          />

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button type="submit">
              {editingCompany ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
