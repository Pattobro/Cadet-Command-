import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import Modal from "@/react-app/components/Modal";
import Button from "@/react-app/components/Button";
import Input from "@/react-app/components/Input";
import Textarea from "@/react-app/components/Textarea";
import { Plus, Edit2, Trash2, Calendar, Download } from "lucide-react";
import { EventType } from "@/shared/types";

export default function Events() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [events, setEvents] = useState<EventType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<EventType | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    event_date: "",
    location: "",
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchEvents();
    }
  }, [user]);

  const fetchEvents = async () => {
    const response = await fetch("/api/events");
    const data = await response.json();
    setEvents(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      description: formData.description || null,
      location: formData.location || null,
    };

    if (editingEvent) {
      await fetch(`/api/events/${editingEvent.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    fetchEvents();
    closeModal();
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this event?")) {
      await fetch(`/api/events/${id}`, { method: "DELETE" });
      fetchEvents();
    }
  };

  const openModal = (event?: EventType) => {
    if (event) {
      setEditingEvent(event);
      setFormData({
        name: event.name,
        description: event.description || "",
        event_date: event.event_date,
        location: event.location || "",
      });
    } else {
      setEditingEvent(null);
      setFormData({
        name: "",
        description: "",
        event_date: "",
        location: "",
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingEvent(null);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const addToCalendar = (event: EventType) => {
    const eventDate = new Date(event.event_date);
    const startDate = eventDate.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    const endDate = new Date(eventDate.getTime() + 3600000).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Cadet Command//Events//EN',
      'BEGIN:VEVENT',
      `DTSTART:${startDate}`,
      `DTEND:${endDate}`,
      `SUMMARY:${event.name}`,
      event.description ? `DESCRIPTION:${event.description.replace(/\n/g, '\\n')}` : '',
      event.location ? `LOCATION:${event.location}` : '',
      `UID:${event.id}@cadetcommand.mocha.app`,
      'END:VEVENT',
      'END:VCALENDAR'
    ].filter(line => line).join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${event.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (isPending || !user) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Events</h1>
            <p className="text-slate-400">Manage JROTC events and activities</p>
          </div>
          <Button onClick={() => openModal()}>
            <Plus className="w-5 h-5 mr-2 inline" />
            Add Event
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {events.map((event) => (
            <div
              key={event.id}
              className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
                    <Calendar className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{event.name}</h3>
                    <p className="text-sm text-[#d4af37]">{formatDate(event.event_date)}</p>
                  </div>
                </div>
              </div>

              {event.description && (
                <p className="text-sm text-slate-400 mb-3">{event.description}</p>
              )}

              {event.location && (
                <p className="text-xs text-slate-500 mb-4">📍 {event.location}</p>
              )}

              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => addToCalendar(event)}
                  className="p-2 text-[#d4af37] hover:bg-[#d4af37]/10 rounded-lg transition-all"
                  title="Add to Calendar"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={() => openModal(event)}
                  className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(event.id!)}
                  className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {events.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">No events yet. Add your first event to get started.</p>
          </div>
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingEvent ? "Edit Event" : "Add Event"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Event Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., Annual Awards Ceremony"
            required
          />

          <Input
            label="Event Date"
            type="date"
            value={formData.event_date}
            onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
            required
          />

          <Input
            label="Location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="e.g., School Auditorium"
          />

          <Textarea
            label="Description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Event details and information..."
            rows={4}
          />

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button type="submit">
              {editingEvent ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
