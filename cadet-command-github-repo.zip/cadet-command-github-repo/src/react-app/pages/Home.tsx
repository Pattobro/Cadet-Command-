import { useEffect } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Loader2, Shield } from "lucide-react";

export default function Home() {
  const { user, isPending, redirectToLogin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isPending && user) {
      navigate("/dashboard");
    }
  }, [user, isPending, navigate]);

  if (isPending) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#17190a]">
        <div className="animate-spin">
          <Loader2 className="w-10 h-10 text-[#d4af37]" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#17190a] flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center space-y-8">
        <div className="flex items-center justify-center space-x-3">
          <Shield className="w-16 h-16 text-[#d4af37]" strokeWidth={1.5} />
          <h1 className="text-6xl font-bold tracking-tight">
            <span className="text-white">Cadet</span>{" "}
            <span className="text-[#d4af37]">Command</span>
          </h1>
        </div>
        
        <p className="text-xl text-slate-300 max-w-lg mx-auto">
          Professional JROTC cadet management system for organizing platoons, companies, events, and disciplinary records.
        </p>

        <div className="pt-8">
          <button
            onClick={redirectToLogin}
            className="px-8 py-4 bg-[#d4af37] text-[#17190a] font-semibold rounded-lg hover:bg-[#c49f2f] transition-all duration-200 transform hover:scale-105 shadow-lg shadow-[#d4af37]/20"
          >
            Sign In with Google
          </button>
        </div>

        <div className="pt-12 grid grid-cols-3 gap-8 text-sm">
          <div className="space-y-2">
            <div className="w-12 h-12 mx-auto bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
              <div className="w-6 h-6 border-2 border-[#d4af37] rounded" />
            </div>
            <p className="text-slate-300 font-medium">Organized Structure</p>
          </div>
          <div className="space-y-2">
            <div className="w-12 h-12 mx-auto bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
              <div className="w-6 h-6 border-2 border-[#d4af37] rounded-full" />
            </div>
            <p className="text-slate-300 font-medium">Discipline Tracking</p>
          </div>
          <div className="space-y-2">
            <div className="w-12 h-12 mx-auto bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
              <div className="w-6 h-6 flex space-x-1">
                <div className="w-1.5 bg-[#d4af37]" />
                <div className="w-1.5 bg-[#d4af37]" />
                <div className="w-1.5 bg-[#d4af37]" />
              </div>
            </div>
            <p className="text-slate-300 font-medium">Military Precision</p>
          </div>
        </div>
      </div>
    </div>
  );
}
