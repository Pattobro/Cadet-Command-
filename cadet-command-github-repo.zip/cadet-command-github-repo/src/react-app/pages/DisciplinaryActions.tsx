import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import Modal from "@/react-app/components/Modal";
import Button from "@/react-app/components/Button";
import Input from "@/react-app/components/Input";
import Select from "@/react-app/components/Select";
import Textarea from "@/react-app/components/Textarea";
import { Plus, Edit2, Trash2, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { DisciplinaryActionType, CadetType, SEVERITY_LEVELS } from "@/shared/types";

export default function DisciplinaryActions() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [actions, setActions] = useState<DisciplinaryActionType[]>([]);
  const [cadets, setCadets] = useState<CadetType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAction, setEditingAction] = useState<DisciplinaryActionType | null>(null);
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "resolved">("all");
  const [formData, setFormData] = useState<{
    cadet_id: string;
    infraction: string;
    severity: typeof SEVERITY_LEVELS[number];
    corrective_action: string;
    incident_date: string;
    resolution_date: string;
    notes: string;
    is_resolved: number;
  }>({
    cadet_id: "",
    infraction: "",
    severity: SEVERITY_LEVELS[0],
    corrective_action: "",
    incident_date: "",
    resolution_date: "",
    notes: "",
    is_resolved: 0,
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchActions();
      fetchCadets();
    }
  }, [user]);

  const fetchActions = async () => {
    const response = await fetch("/api/disciplinary-actions");
    const data = await response.json();
    setActions(data);
  };

  const fetchCadets = async () => {
    const response = await fetch("/api/cadets");
    const data = await response.json();
    setCadets(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      cadet_id: Number(formData.cadet_id),
      resolution_date: formData.resolution_date || null,
      notes: formData.notes || null,
      is_resolved: formData.is_resolved,
    };

    if (editingAction) {
      await fetch(`/api/disciplinary-actions/${editingAction.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/disciplinary-actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    fetchActions();
    closeModal();
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this disciplinary action?")) {
      await fetch(`/api/disciplinary-actions/${id}`, { method: "DELETE" });
      fetchActions();
    }
  };

  const openModal = (action?: DisciplinaryActionType) => {
    if (action) {
      setEditingAction(action);
      setFormData({
        cadet_id: action.cadet_id.toString(),
        infraction: action.infraction,
        severity: action.severity,
        corrective_action: action.corrective_action,
        incident_date: action.incident_date,
        resolution_date: action.resolution_date || "",
        notes: action.notes || "",
        is_resolved: action.is_resolved || 0,
      });
    } else {
      setEditingAction(null);
      setFormData({
        cadet_id: "",
        infraction: "",
        severity: SEVERITY_LEVELS[0],
        corrective_action: "",
        incident_date: "",
        resolution_date: "",
        notes: "",
        is_resolved: 0,
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingAction(null);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const getCadetName = (cadetId: number) => {
    const cadet = cadets.find((c) => c.id === cadetId);
    return cadet ? `${cadet.first_name} ${cadet.last_name}` : "Unknown";
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Minor":
        return "text-blue-400 bg-blue-400/10 border-blue-400/30";
      case "Moderate":
        return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
      case "Serious":
        return "text-orange-400 bg-orange-400/10 border-orange-400/30";
      case "Severe":
        return "text-red-400 bg-red-400/10 border-red-400/30";
      default:
        return "text-slate-400 bg-slate-400/10 border-slate-400/30";
    }
  };

  const filteredActions = actions.filter((action) => {
    if (filterStatus === "active") return !action.is_resolved;
    if (filterStatus === "resolved") return action.is_resolved;
    return true;
  });

  if (isPending || !user) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Disciplinary Actions</h1>
            <p className="text-slate-400">Track infractions and corrective measures</p>
          </div>
          <Button onClick={() => openModal()}>
            <Plus className="w-5 h-5 mr-2 inline" />
            Log Action
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setFilterStatus("all")}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              filterStatus === "all"
                ? "bg-[#d4af37] text-[#17190a]"
                : "bg-[#4B5320]/30 text-slate-300 hover:bg-[#4B5320]/50"
            }`}
          >
            All ({actions.length})
          </button>
          <button
            onClick={() => setFilterStatus("active")}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              filterStatus === "active"
                ? "bg-[#d4af37] text-[#17190a]"
                : "bg-[#4B5320]/30 text-slate-300 hover:bg-[#4B5320]/50"
            }`}
          >
            Active ({actions.filter((a) => !a.is_resolved).length})
          </button>
          <button
            onClick={() => setFilterStatus("resolved")}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              filterStatus === "resolved"
                ? "bg-[#d4af37] text-[#17190a]"
                : "bg-[#4B5320]/30 text-slate-300 hover:bg-[#4B5320]/50"
            }`}
          >
            Resolved ({actions.filter((a) => a.is_resolved).length})
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredActions.map((action) => (
            <div
              key={action.id}
              className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
                    {action.is_resolved ? (
                      <CheckCircle className="w-6 h-6 text-green-400" />
                    ) : (
                      <AlertTriangle className="w-6 h-6 text-red-400" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{getCadetName(action.cadet_id)}</h3>
                    <p className="text-xs text-slate-400">{formatDate(action.incident_date)}</p>
                  </div>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold border ${getSeverityColor(
                    action.severity
                  )}`}
                >
                  {action.severity}
                </span>
              </div>

              <div className="space-y-3 mb-4">
                <div>
                  <p className="text-xs text-slate-500 mb-1">Infraction</p>
                  <p className="text-sm text-white font-medium">{action.infraction}</p>
                </div>

                <div>
                  <p className="text-xs text-slate-500 mb-1">Corrective Action</p>
                  <p className="text-sm text-slate-300">{action.corrective_action}</p>
                </div>

                {action.notes && (
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Notes</p>
                    <p className="text-sm text-slate-400">{action.notes}</p>
                  </div>
                )}

                {action.is_resolved && action.resolution_date && (
                  <div className="flex items-center space-x-2 text-green-400 text-xs">
                    <CheckCircle className="w-4 h-4" />
                    <span>Resolved on {formatDate(action.resolution_date)}</span>
                  </div>
                )}

                {!action.is_resolved && (
                  <div className="flex items-center space-x-2 text-red-400 text-xs">
                    <XCircle className="w-4 h-4" />
                    <span>Pending Resolution</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => openModal(action)}
                  className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(action.id!)}
                  className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredActions.length === 0 && (
          <div className="text-center py-12">
            <AlertTriangle className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">
              {filterStatus === "all"
                ? "No disciplinary actions yet."
                : filterStatus === "active"
                ? "No active disciplinary actions."
                : "No resolved disciplinary actions."}
            </p>
          </div>
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingAction ? "Edit Disciplinary Action" : "Log Disciplinary Action"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Select
            label="Cadet"
            value={formData.cadet_id}
            onChange={(e) => setFormData({ ...formData, cadet_id: e.target.value })}
            options={[
              { value: "", label: "Select Cadet" },
              ...cadets.map((c) => ({
                value: c.id!,
                label: `${c.first_name} ${c.last_name} - ${c.rank}`,
              })),
            ]}
            required
          />

          <Input
            label="Infraction"
            value={formData.infraction}
            onChange={(e) => setFormData({ ...formData, infraction: e.target.value })}
            placeholder="e.g., Uniform violation, Late to formation"
            required
          />

          <Select
            label="Severity Level"
            value={formData.severity}
            onChange={(e) => setFormData({ ...formData, severity: e.target.value as any })}
            options={SEVERITY_LEVELS.map((level) => ({ value: level, label: level }))}
            required
          />

          <Input
            label="Incident Date"
            type="date"
            value={formData.incident_date}
            onChange={(e) => setFormData({ ...formData, incident_date: e.target.value })}
            required
          />

          <Textarea
            label="Corrective Action"
            value={formData.corrective_action}
            onChange={(e) => setFormData({ ...formData, corrective_action: e.target.value })}
            placeholder="Describe the corrective action taken..."
            rows={3}
            required
          />

          <Textarea
            label="Additional Notes"
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            placeholder="Any additional context or details..."
            rows={3}
          />

          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="is_resolved"
              checked={formData.is_resolved === 1}
              onChange={(e) =>
                setFormData({ ...formData, is_resolved: e.target.checked ? 1 : 0 })
              }
              className="w-5 h-5 bg-[#17190a] border-[#d4af37]/30 rounded"
            />
            <label htmlFor="is_resolved" className="text-slate-300 font-medium">
              Mark as Resolved
            </label>
          </div>

          {formData.is_resolved === 1 && (
            <Input
              label="Resolution Date"
              type="date"
              value={formData.resolution_date}
              onChange={(e) => setFormData({ ...formData, resolution_date: e.target.value })}
            />
          )}

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button type="submit">{editingAction ? "Update" : "Create"}</Button>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
