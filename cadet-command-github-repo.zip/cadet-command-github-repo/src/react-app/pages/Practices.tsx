import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import Modal from "@/react-app/components/Modal";
import Button from "@/react-app/components/Button";
import Input from "@/react-app/components/Input";
import Textarea from "@/react-app/components/Textarea";
import { Plus, Edit2, Trash2, Dumbbell } from "lucide-react";
import { PracticeType } from "@/shared/types";

export default function Practices() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [practices, setPractices] = useState<PracticeType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPractice, setEditingPractice] = useState<PracticeType | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    practice_date: "",
    location: "",
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchPractices();
    }
  }, [user]);

  const fetchPractices = async () => {
    const response = await fetch("/api/practices");
    const data = await response.json();
    setPractices(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      description: formData.description || null,
      location: formData.location || null,
    };

    if (editingPractice) {
      await fetch(`/api/practices/${editingPractice.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/practices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    fetchPractices();
    closeModal();
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this practice?")) {
      await fetch(`/api/practices/${id}`, { method: "DELETE" });
      fetchPractices();
    }
  };

  const openModal = (practice?: PracticeType) => {
    if (practice) {
      setEditingPractice(practice);
      setFormData({
        name: practice.name,
        description: practice.description || "",
        practice_date: practice.practice_date,
        location: practice.location || "",
      });
    } else {
      setEditingPractice(null);
      setFormData({
        name: "",
        description: "",
        practice_date: "",
        location: "",
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingPractice(null);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (isPending || !user) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Practices</h1>
            <p className="text-slate-400">Manage practice sessions and drills</p>
          </div>
          <Button onClick={() => openModal()}>
            <Plus className="w-5 h-5 mr-2 inline" />
            Add Practice
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {practices.map((practice) => (
            <div
              key={practice.id}
              className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
                    <Dumbbell className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{practice.name}</h3>
                    <p className="text-sm text-[#d4af37]">{formatDate(practice.practice_date)}</p>
                  </div>
                </div>
              </div>

              {practice.description && (
                <p className="text-sm text-slate-400 mb-3">{practice.description}</p>
              )}

              {practice.location && (
                <p className="text-xs text-slate-500 mb-4">📍 {practice.location}</p>
              )}

              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => openModal(practice)}
                  className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(practice.id!)}
                  className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {practices.length === 0 && (
          <div className="text-center py-12">
            <Dumbbell className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">No practices yet. Add your first practice to get started.</p>
          </div>
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingPractice ? "Edit Practice" : "Add Practice"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Practice Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., Drill and Ceremony Practice"
            required
          />

          <Input
            label="Practice Date"
            type="date"
            value={formData.practice_date}
            onChange={(e) => setFormData({ ...formData, practice_date: e.target.value })}
            required
          />

          <Input
            label="Location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="e.g., School Gymnasium"
          />

          <Textarea
            label="Description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Practice details and focus areas..."
            rows={4}
          />

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button type="submit">
              {editingPractice ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
