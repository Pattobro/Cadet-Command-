import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import Modal from "@/react-app/components/Modal";
import Button from "@/react-app/components/Button";
import Input from "@/react-app/components/Input";
import Select from "@/react-app/components/Select";
import { Plus, Edit2, Trash2, Layers } from "lucide-react";
import { PlatoonType, CompanyType, CadetType } from "@/shared/types";

export default function Platoons() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [platoons, setPlatoons] = useState<PlatoonType[]>([]);
  const [companies, setCompanies] = useState<CompanyType[]>([]);
  const [cadets, setCadets] = useState<CadetType[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlatoon, setEditingPlatoon] = useState<PlatoonType | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    commander_id: "",
    company_id: "",
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchPlatoons();
      fetchCompanies();
      fetchCadets();
    }
  }, [user]);

  const fetchPlatoons = async () => {
    const response = await fetch("/api/platoons");
    const data = await response.json();
    setPlatoons(data);
  };

  const fetchCompanies = async () => {
    const response = await fetch("/api/companies");
    const data = await response.json();
    setCompanies(data);
  };

  const fetchCadets = async () => {
    const response = await fetch("/api/cadets");
    const data = await response.json();
    setCadets(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      commander_id: formData.commander_id ? Number(formData.commander_id) : null,
      company_id: formData.company_id ? Number(formData.company_id) : null,
    };

    if (editingPlatoon) {
      await fetch(`/api/platoons/${editingPlatoon.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/platoons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    fetchPlatoons();
    closeModal();
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this platoon?")) {
      await fetch(`/api/platoons/${id}`, { method: "DELETE" });
      fetchPlatoons();
    }
  };

  const openModal = (platoon?: PlatoonType) => {
    if (platoon) {
      setEditingPlatoon(platoon);
      setFormData({
        name: platoon.name,
        commander_id: platoon.commander_id?.toString() || "",
        company_id: platoon.company_id?.toString() || "",
      });
    } else {
      setEditingPlatoon(null);
      setFormData({
        name: "",
        commander_id: "",
        company_id: "",
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingPlatoon(null);
  };

  const getCommanderName = (commanderId: number | null | undefined) => {
    if (!commanderId) return "Unassigned";
    const commander = cadets.find((c) => c.id === commanderId);
    return commander ? `${commander.first_name} ${commander.last_name}` : "Unknown";
  };

  const getCompanyName = (companyId: number | null | undefined) => {
    if (!companyId) return "No Company";
    const company = companies.find((c) => c.id === companyId);
    return company ? company.name : "Unknown";
  };

  if (isPending || !user) {
    return null;
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Platoons</h1>
            <p className="text-slate-400">Manage platoon organization and commanders</p>
          </div>
          <Button onClick={() => openModal()}>
            <Plus className="w-5 h-5 mr-2 inline" />
            Add Platoon
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {platoons.map((platoon) => (
            <div
              key={platoon.id}
              className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-[#4B5320]/30 rounded-lg flex items-center justify-center border border-[#d4af37]/30">
                    <Layers className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{platoon.name}</h3>
                    <p className="text-sm text-slate-400">{getCompanyName(platoon.company_id)}</p>
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-xs text-slate-500 mb-1">Platoon Commander</p>
                <p className="text-sm text-[#d4af37] font-medium">{getCommanderName(platoon.commander_id)}</p>
              </div>

              <div className="flex items-center justify-end space-x-2">
                <button
                  onClick={() => openModal(platoon)}
                  className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(platoon.id!)}
                  className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {platoons.length === 0 && (
          <div className="text-center py-12">
            <Layers className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">No platoons yet. Add your first platoon to get started.</p>
          </div>
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingPlatoon ? "Edit Platoon" : "Add Platoon"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Platoon Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., 1st Platoon"
            required
          />

          <Select
            label="Platoon Commander"
            value={formData.commander_id}
            onChange={(e) => setFormData({ ...formData, commander_id: e.target.value })}
            options={[
              { value: "", label: "Select Commander" },
              ...cadets.map((c) => ({
                value: c.id!,
                label: `${c.first_name} ${c.last_name} - ${c.rank}`,
              })),
            ]}
          />

          <Select
            label="Company"
            value={formData.company_id}
            onChange={(e) => setFormData({ ...formData, company_id: e.target.value })}
            options={[
              { value: "", label: "None" },
              ...companies.map((c) => ({ value: c.id!, label: c.name })),
            ]}
          />

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button type="submit">
              {editingPlatoon ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </Modal>
    </Layout>
  );
}
