import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Layout from "@/react-app/components/Layout";
import { Users, Layers, Building2, GraduationCap, Calendar, Dumbbell, AlertTriangle, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    cadets: 0,
    platoons: 0,
    companies: 0,
    instructors: 0,
    events: 0,
    practices: 0,
    disciplinary: 0,
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [cadets, platoons, companies, instructors, events, practices, disciplinary] =
          await Promise.all([
            fetch("/api/cadets").then((r) => r.json()),
            fetch("/api/platoons").then((r) => r.json()),
            fetch("/api/companies").then((r) => r.json()),
            fetch("/api/instructors").then((r) => r.json()),
            fetch("/api/events").then((r) => r.json()),
            fetch("/api/practices").then((r) => r.json()),
            fetch("/api/disciplinary-actions").then((r) => r.json()),
          ]);

        setStats({
          cadets: cadets.length,
          platoons: platoons.length,
          companies: companies.length,
          instructors: instructors.length,
          events: events.length,
          practices: practices.length,
          disciplinary: disciplinary.filter((d: any) => !d.is_resolved).length,
        });
      } catch (error) {
        console.error("Failed to fetch stats:", error);
      }
    };

    if (user) {
      fetchStats();
    }
  }, [user]);

  if (isPending || !user) {
    return null;
  }

  const statCards = [
    { label: "Cadets", value: stats.cadets, icon: Users, color: "text-blue-400", path: "/cadets" },
    { label: "Platoons", value: stats.platoons, icon: Layers, color: "text-purple-400", path: "/platoons" },
    { label: "Companies", value: stats.companies, icon: Building2, color: "text-green-400", path: "/companies" },
    { label: "Instructors", value: stats.instructors, icon: GraduationCap, color: "text-orange-400", path: "/instructors" },
    { label: "Events", value: stats.events, icon: Calendar, color: "text-cyan-400", path: "/events" },
    { label: "Practices", value: stats.practices, icon: Dumbbell, color: "text-pink-400", path: "/practices" },
    { label: "Active Disciplinary", value: stats.disciplinary, icon: AlertTriangle, color: "text-red-400", path: "/disciplinary-actions" },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2">Command Dashboard</h1>
          <p className="text-slate-400">Welcome back, {user.google_user_data.given_name || user.email}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {statCards.map((stat) => {
            const Icon = stat.icon;
            return (
              <button
                key={stat.label}
                onClick={() => navigate(stat.path)}
                className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6 hover:border-[#d4af37] transition-all transform hover:scale-105 shadow-lg hover:shadow-xl text-left"
              >
                <div className="flex items-center justify-between mb-4">
                  <Icon className={`w-8 h-8 ${stat.color}`} strokeWidth={1.5} />
                  <TrendingUp className="w-5 h-5 text-slate-500" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-sm text-slate-400">{stat.label}</p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center">
              <div className="w-1 h-6 bg-[#d4af37] mr-3 rounded" />
              Quick Actions
            </h2>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => navigate("/cadets")}
                className="bg-[#4B5320]/30 hover:bg-[#4B5320]/50 border border-[#d4af37]/20 rounded-lg p-4 text-left transition-all"
              >
                <p className="text-sm text-[#d4af37] font-semibold">Add Cadet</p>
              </button>
              <button
                onClick={() => navigate("/events")}
                className="bg-[#4B5320]/30 hover:bg-[#4B5320]/50 border border-[#d4af37]/20 rounded-lg p-4 text-left transition-all"
              >
                <p className="text-sm text-[#d4af37] font-semibold">New Event</p>
              </button>
              <button
                onClick={() => navigate("/practices")}
                className="bg-[#4B5320]/30 hover:bg-[#4B5320]/50 border border-[#d4af37]/20 rounded-lg p-4 text-left transition-all"
              >
                <p className="text-sm text-[#d4af37] font-semibold">Schedule Practice</p>
              </button>
              <button
                onClick={() => navigate("/disciplinary-actions")}
                className="bg-[#4B5320]/30 hover:bg-[#4B5320]/50 border border-[#d4af37]/20 rounded-lg p-4 text-left transition-all"
              >
                <p className="text-sm text-[#d4af37] font-semibold">Log Incident</p>
              </button>
            </div>
          </div>

          <div className="bg-[#1f2212] border border-[#d4af37]/30 rounded-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center">
              <div className="w-1 h-6 bg-[#d4af37] mr-3 rounded" />
              System Overview
            </h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-[#4B5320]/20 rounded-lg border border-[#d4af37]/10">
                <span className="text-slate-300">Total Personnel</span>
                <span className="text-white font-semibold">{stats.cadets + stats.instructors}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-[#4B5320]/20 rounded-lg border border-[#d4af37]/10">
                <span className="text-slate-300">Organizational Units</span>
                <span className="text-white font-semibold">{stats.platoons + stats.companies}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-[#4B5320]/20 rounded-lg border border-[#d4af37]/10">
                <span className="text-slate-300">Scheduled Activities</span>
                <span className="text-white font-semibold">{stats.events + stats.practices}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
