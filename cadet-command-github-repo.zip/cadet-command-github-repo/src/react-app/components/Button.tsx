import { ReactNode, ButtonHTMLAttributes } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger";
  children: ReactNode;
}

export default function Button({
  variant = "primary",
  children,
  className = "",
  ...props
}: ButtonProps) {
  const baseStyles = "px-4 py-2 rounded-lg font-semibold transition-all duration-200";
  
  const variantStyles = {
    primary: "bg-[#d4af37] text-[#17190a] hover:bg-[#c49f2f] shadow-md shadow-[#d4af37]/20",
    secondary: "bg-[#4B5320] text-white hover:bg-[#5a6428] border border-[#d4af37]/30",
    danger: "bg-red-900/80 text-white hover:bg-red-900 border border-red-700",
  };

  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
