import { ReactNode } from "react";
import { Link, useLocation, useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import {
  Shield,
  Users,
  Layers,
  Building2,
  GraduationCap,
  Calendar,
  Dumbbell,
  AlertTriangle,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const navItems = [
    { path: "/dashboard", label: "Dashboard", icon: Shield },
    { path: "/cadets", label: "Cadets", icon: Users },
    { path: "/platoons", label: "Platoons", icon: Layers },
    { path: "/companies", label: "Companies", icon: Building2 },
    { path: "/instructors", label: "Instructors", icon: GraduationCap },
    { path: "/events", label: "Events", icon: Calendar },
    { path: "/practices", label: "Practices", icon: Dumbbell },
    { path: "/disciplinary-actions", label: "Disciplinary", icon: AlertTriangle },
  ];

  return (
    <div className="min-h-screen bg-[#17190a] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:flex-col w-64 bg-[#1f2212] border-r border-[#d4af37]/20">
        <div className="p-6 border-b border-[#d4af37]/20">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-[#d4af37]" strokeWidth={1.5} />
            <h1 className="text-xl font-bold">
              <span className="text-white">Cadet</span>{" "}
              <span className="text-[#d4af37]">Command</span>
            </h1>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? "bg-[#d4af37] text-[#17190a] font-semibold shadow-lg shadow-[#d4af37]/20"
                    : "text-slate-300 hover:bg-[#4B5320]/30 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5" strokeWidth={isActive ? 2.5 : 2} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[#d4af37]/20">
          <button
            onClick={handleLogout}
            className="flex items-center space-x-3 px-4 py-3 w-full rounded-lg text-slate-300 hover:bg-red-900/20 hover:text-red-400 transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-[#1f2212] border-b border-[#d4af37]/20 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-2">
            <Shield className="w-6 h-6 text-[#d4af37]" strokeWidth={1.5} />
            <h1 className="text-lg font-bold">
              <span className="text-white">Cadet</span>{" "}
              <span className="text-[#d4af37]">Command</span>
            </h1>
          </div>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-slate-300 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="bg-[#1f2212] border-t border-[#d4af37]/20 p-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                    isActive
                      ? "bg-[#d4af37] text-[#17190a] font-semibold"
                      : "text-slate-300 hover:bg-[#4B5320]/30 hover:text-white"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
            <button
              onClick={handleLogout}
              className="flex items-center space-x-3 px-4 py-3 w-full rounded-lg text-slate-300 hover:bg-red-900/20 hover:text-red-400 transition-all"
            >
              <LogOut className="w-5 h-5" />
              <span>Sign Out</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Content */}
      <main className="flex-1 md:p-8 p-4 pt-20 md:pt-8 overflow-auto">
        {children}
      </main>
    </div>
  );
}
