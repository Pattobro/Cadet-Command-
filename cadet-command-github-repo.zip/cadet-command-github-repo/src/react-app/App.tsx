import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import HomePage from "@/react-app/pages/Home";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import DashboardPage from "@/react-app/pages/Dashboard";
import CadetsPage from "@/react-app/pages/Cadets";
import PlatoonsPage from "@/react-app/pages/Platoons";
import CompaniesPage from "@/react-app/pages/Companies";
import InstructorsPage from "@/react-app/pages/Instructors";
import EventsPage from "@/react-app/pages/Events";
import PracticesPage from "@/react-app/pages/Practices";
import DisciplinaryActionsPage from "@/react-app/pages/DisciplinaryActions";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/cadets" element={<CadetsPage />} />
          <Route path="/platoons" element={<PlatoonsPage />} />
          <Route path="/companies" element={<CompaniesPage />} />
          <Route path="/instructors" element={<InstructorsPage />} />
          <Route path="/events" element={<EventsPage />} />
          <Route path="/practices" element={<PracticesPage />} />
          <Route path="/disciplinary-actions" element={<DisciplinaryActionsPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
