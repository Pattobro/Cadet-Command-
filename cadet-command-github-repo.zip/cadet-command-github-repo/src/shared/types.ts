import z from "zod";

// Cadet ranks
export const CADET_RANKS = [
  "Private",
  "Private First Class",
  "Corporal",
  "Sergeant",
  "Staff Sergeant",
  "Sergeant First Class",
  "Master Sergeant",
  "First Sergeant",
  "Sergeant Major",
  "Second Lieutenant",
  "First Lieutenant",
  "Captain",
  "Major",
  "Lieutenant Colonel"
] as const;

// Instructor ranks
export const INSTRUCTOR_RANKS = [
  "Sergeant",
  "Sergeant Major",
  "Second Lieutenant",
  "First Lieutenant",
  "Captain",
  "Major",
  "Lieutenant Colonel",
  "Colonel"
] as const;

// Armed forces branches
export const BRANCHES = [
  "Army",
  "Navy",
  "Air Force",
  "Marine Corps",
  "Coast Guard",
  "Space Force"
] as const;

// Severity levels
export const SEVERITY_LEVELS = [
  "Minor",
  "Moderate",
  "Serious",
  "Severe"
] as const;

// Cadet schema
export const CadetSchema = z.object({
  id: z.number().optional(),
  user_id: z.string().optional(),
  first_name: z.string().min(1),
  last_name: z.string().min(1),
  rank: z.enum(CADET_RANKS),
  platoon_id: z.number().nullable().optional(),
  company_id: z.number().nullable().optional(),
  email: z.string().email().nullable().optional(),
  phone: z.string().nullable().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type CadetType = z.infer<typeof CadetSchema>;

// Platoon schema
export const PlatoonSchema = z.object({
  id: z.number().optional(),
  user_id: z.string().optional(),
  name: z.string().min(1),
  commander_id: z.number().nullable().optional(),
  company_id: z.number().nullable().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type PlatoonType = z.infer<typeof PlatoonSchema>;

// Company schema
export const CompanySchema = z.object({
  id: z.number().optional(),
  user_id: z.string().optional(),
  name: z.string().min(1),
  commander_id: z.number().nullable().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type CompanyType = z.infer<typeof CompanySchema>;

// Instructor schema
export const InstructorSchema = z.object({
  id: z.number().optional(),
  user_id: z.string().optional(),
  first_name: z.string().min(1),
  last_name: z.string().min(1),
  rank: z.enum(INSTRUCTOR_RANKS),
  branch: z.enum(BRANCHES),
  email: z.string().email().nullable().optional(),
  phone: z.string().nullable().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type InstructorType = z.infer<typeof InstructorSchema>;

// Event schema
export const EventSchema = z.object({
  id: z.number().optional(),
  user_id: z.string().optional(),
  name: z.string().min(1),
  description: z.string().nullable().optional(),
  event_date: z.string(),
  location: z.string().nullable().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type EventType = z.infer<typeof EventSchema>;

// Practice schema
export const PracticeSchema = z.object({
  id: z.number().optional(),
  user_id: z.string().optional(),
  name: z.string().min(1),
  description: z.string().nullable().optional(),
  practice_date: z.string(),
  location: z.string().nullable().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type PracticeType = z.infer<typeof PracticeSchema>;

// Disciplinary action schema
export const DisciplinaryActionSchema = z.object({
  id: z.number().optional(),
  user_id: z.string().optional(),
  cadet_id: z.number(),
  infraction: z.string().min(1),
  severity: z.enum(SEVERITY_LEVELS),
  corrective_action: z.string().min(1),
  incident_date: z.string(),
  resolution_date: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
  is_resolved: z.number().optional(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type DisciplinaryActionType = z.infer<typeof DisciplinaryActionSchema>;
