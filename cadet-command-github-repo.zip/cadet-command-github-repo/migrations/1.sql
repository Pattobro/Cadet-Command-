
CREATE TABLE cadets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  rank TEXT NOT NULL,
  platoon_id INTEGER,
  company_id INTEGER,
  email TEXT,
  phone TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE platoons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  commander_id INTEGER,
  company_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  commander_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE instructors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  rank TEXT NOT NULL,
  branch TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  event_date DATE NOT NULL,
  location TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE practices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  practice_date DATE NOT NULL,
  location TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE disciplinary_actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  cadet_id INTEGER NOT NULL,
  infraction TEXT NOT NULL,
  severity TEXT NOT NULL,
  corrective_action TEXT NOT NULL,
  incident_date DATE NOT NULL,
  resolution_date DATE,
  notes TEXT,
  is_resolved BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cadets_user_id ON cadets(user_id);
CREATE INDEX idx_cadets_platoon_id ON cadets(platoon_id);
CREATE INDEX idx_cadets_company_id ON cadets(company_id);
CREATE INDEX idx_platoons_user_id ON platoons(user_id);
CREATE INDEX idx_platoons_company_id ON platoons(company_id);
CREATE INDEX idx_companies_user_id ON companies(user_id);
CREATE INDEX idx_instructors_user_id ON instructors(user_id);
CREATE INDEX idx_events_user_id ON events(user_id);
CREATE INDEX idx_practices_user_id ON practices(user_id);
CREATE INDEX idx_disciplinary_actions_user_id ON disciplinary_actions(user_id);
CREATE INDEX idx_disciplinary_actions_cadet_id ON disciplinary_actions(cadet_id);
